// background.js — auto-scan setiap URL yang dikunjungi
// Menggunakan model.js (no API needed)

importScripts("model.js");

const SKIP = [/^chrome:\/\//, /^chrome-extension:\/\//, /^about:/, /^file:/, /^data:/];

chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  if (changeInfo.status !== "complete") return;
  if (!tab.url || SKIP.some(p => p.test(tab.url))) return;

  try {
    const result = await predictURL(tab.url);
    if (result.label === "phishing") {
      chrome.tabs.sendMessage(tabId, {
        type: "SHOW_WARNING",
        url: tab.url
      }).catch(() => { });
    }
    await saveHistory(tab.url, result);
    updateBadge(tabId, result);
    chrome.runtime.sendMessage({ type: "AUTO_SCAN_RESULT", url: tab.url, result }).catch(() => { });
  } catch (e) {
    console.error("Auto-scan error:", e);

  }
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "MANUAL_SCAN") {
    predictURL(msg.url)
      .then(result => {
        saveHistory(msg.url, result);
        sendResponse({ success: true, result });
      })
      .catch(err => sendResponse({ success: false, error: err.message }));
    return true;
  }
  if (msg.type === "GET_HISTORY") {
    chrome.storage.local.get("history", d => sendResponse({ history: d.history || [] }));
    return true;
  }
  if (msg.type === "CLEAR_HISTORY") {
    chrome.storage.local.set({ history: [] }, () => sendResponse({ success: true }));
    return true;
  }
});

async function saveHistory(url, result) {
  return new Promise(resolve => {
    chrome.storage.local.get("history", d => {
      const h = d.history || [];
      h.unshift({ url, label: result.label, confidence: result.confidence, timestamp: Date.now() });
      if (h.length > 100) h.splice(100);
      chrome.storage.local.set({ history: h }, resolve);
    });
  });
}

function updateBadge(tabId, result) {
  if (result.label === "phishing") {
    chrome.action.setBadgeText({ tabId, text: "!" });
    chrome.action.setBadgeBackgroundColor({ tabId, color: "#D85A30" });
  } else if (result.label === "safe") {
    chrome.action.setBadgeText({ tabId, text: "✓" });
    chrome.action.setBadgeBackgroundColor({ tabId, color: "#1D9E75" });
  } else {
    chrome.action.setBadgeText({ tabId, text: "" });
  }
}
