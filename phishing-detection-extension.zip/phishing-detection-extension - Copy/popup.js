// popup.js — Phishing Detection Extension

const WEBAPP_URL = "https://phishing12.paulinahambali.workers.dev";

let currentTabUrl = "";

document.addEventListener("DOMContentLoaded", async () => {
  await loadCurrentTabUrl();
  await loadHistory();

  document.getElementById("scanBtn").addEventListener("click", doScan);
  document.getElementById("urlInput").addEventListener("keydown", e => { if (e.key === "Enter") doScan(); });
  document.getElementById("currentChip").addEventListener("click", useCurrentUrl);
  document.getElementById("tab-detect").addEventListener("click", () => goTab("detect"));
  document.getElementById("tab-history").addEventListener("click", () => goTab("history"));
  document.getElementById("dashboardBtn").addEventListener("click", openDashboard);
  document.getElementById("exportBtn").addEventListener("click", exportHistory);
  document.getElementById("clearBtn").addEventListener("click", clearHistory);
  document.getElementById("webAppBtn").addEventListener("click", (e) => {
    e.preventDefault();
    chrome.tabs.create({ url: WEBAPP_URL });
  });

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === "AUTO_SCAN_RESULT") {
      updateChipStatus(msg.url, msg.result);
      loadHistory();
    }
  });
});

// ── TAB NAVIGATION ─────────────────────────────────────────
function goTab(name) {
  document.querySelectorAll(".tab").forEach(t => t.classList.remove("on"));
  document.querySelectorAll(".panel").forEach(p => p.classList.remove("on"));
  document.getElementById("tab-" + name).classList.add("on");
  document.getElementById("p-" + name).classList.add("on");
  if (name === "history") loadHistory();
}

// ── CURRENT TAB URL ────────────────────────────────────────
async function loadCurrentTabUrl() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab && tab.url && !tab.url.startsWith("chrome://") && !tab.url.startsWith("chrome-extension://")) {
      currentTabUrl = tab.url;
      document.getElementById("chipUrl").textContent = shortenUrl(tab.url);
      document.getElementById("chipDot").className = "cu-dot";
      document.getElementById("chipAction").textContent = "Gunakan →";
    } else {
      document.getElementById("chipUrl").textContent = "Halaman ini tidak bisa di-scan";
      document.getElementById("chipAction").textContent = "";
      document.getElementById("chipDot").className = "cu-dot offline";
    }
  } catch {
    document.getElementById("chipUrl").textContent = "Tidak dapat membaca URL";
    document.getElementById("chipAction").textContent = "";
  }
}

function useCurrentUrl() {
  if (!currentTabUrl) return;
  document.getElementById("urlInput").value = currentTabUrl;
  goTab("detect");
  doScan();
}

function updateChipStatus(url, result) {
  if (url !== currentTabUrl) return;
  const dot = document.getElementById("chipDot");
  dot.className = "cu-dot" + (result.label === "phishing" ? " phishing" : result.label === "safe" ? " safe" : " offline");
}

// ── SCAN ──────────────────────────────────────────────────
async function doScan() {
  const urlInput = document.getElementById("urlInput");
  const url = urlInput.value.trim();
  if (!url) return;

  const btn = document.getElementById("scanBtn");
  btn.disabled = true;
  btn.textContent = "...";
  showScanning();

  chrome.runtime.sendMessage({ type: "MANUAL_SCAN", url }, (response) => {
    btn.disabled = false;
    btn.textContent = "Scan";
    if (chrome.runtime.lastError || !response) {
      showError("Gagal menghubungi background service.");
      return;
    }
    if (!response.success) {
      showError(response.error || "Gagal scan.");
      return;
    }
    showResult(url, response.result);
    loadHistory();
  });
}

// ── RESULT DISPLAY ─────────────────────────────────────────
function showScanning() {
  const card = document.getElementById("resultCard");
  card.className = "result scanning";
  card.innerHTML = `
    <div class="scan-anim">
      <div class="scan-ring"></div>
      <div class="scan-txt">Menganalisis dengan model ML…</div>
    </div>`;
}

function showResult(url, result) {
  const card = document.getElementById("resultCard");
  const isSafe = result.label === "safe";
  const confPct = Math.round((result.confidence || 0) * 100);
  const features = result.features || {};

  const featHtml = Object.entries(features)
    .filter(([, isBad]) => isBad)
    .slice(0, 6)
    .map(([key]) => `<div class="feat"><div class="feat-dot bad"></div>${escHtml(key)}</div>`)
    .join("") || `<div class="feat" style="color:#c4bdf0;font-style:italic;font-size:10px;">Tidak ada indikator mencurigakan</div>`;

  card.className = `result ${result.label}`;
  card.innerHTML = `
    <div class="res-top">
      <div class="res-status">
        <div class="res-icon ${result.label}">
          <i class="ti ${isSafe ? "ti-shield-check" : "ti-alert-triangle"}" aria-hidden="true"></i>
        </div>
        <span class="res-label ${result.label}">${isSafe ? "Aman" : "Phishing"}</span>
      </div>
      <span class="conf-pill ${result.label}">${confPct}% yakin</span>
    </div>
    <div class="res-url">${escHtml(shortenUrl(url))}</div>
    <div class="feat-grid">${featHtml}</div>
    <div class="bar-lbl">
      <span>${isSafe ? "Skor keamanan" : "Risiko phishing"}</span>
      <span style="color:${isSafe ? "#1D9E75" : "#D85A30"}">${confPct}%</span>
    </div>
    <div class="bar-track">
      <div class="bar-fill ${result.label}" style="width:${confPct}%"></div>
    </div>
    <div class="res-disclaimer">⚠️ Hasil ini adalah prediksi model ML, bukan jaminan keamanan.</div>`;
}

function showError(msg) {
  const card = document.getElementById("resultCard");
  card.className = "result error";
  card.innerHTML = `
    <div class="res-top">
      <div class="res-status">
        <div class="res-icon error"><i class="ti ti-alert-circle" aria-hidden="true"></i></div>
        <span class="res-label error">Gagal</span>
      </div>
    </div>
    <div class="res-disclaimer">${escHtml(msg)}</div>`;
}

// ── HISTORY ────────────────────────────────────────────────
function loadHistory() {
  chrome.runtime.sendMessage({ type: "GET_HISTORY" }, (response) => {
    if (chrome.runtime.lastError || !response) return;
    const history = response.history || [];
    const safe = history.filter(h => h.label === "safe").length;
    const phish = history.filter(h => h.label === "phishing").length;

    document.getElementById("statTotal").textContent = history.length;
    document.getElementById("statSafe").textContent = safe;
    document.getElementById("statPhish").textContent = phish;

    const list = document.getElementById("historyList");
    if (history.length === 0) {
      list.innerHTML = `<div class="empty-state"><i class="ti ti-history" aria-hidden="true"></i>Belum ada riwayat scan</div>`;
      return;
    }

    list.innerHTML = history.slice(0, 10).map(item => {
      const isP = item.label === "phishing";
      const cls = isP ? "p" : "s";
      return `
        <div class="hitem">
          <div class="h-ico ${cls}"><i class="ti ${isP ? "ti-alert-triangle" : "ti-shield-check"}" aria-hidden="true"></i></div>
          <span class="h-url">${escHtml(shortenUrl(item.url))}</span>
          <span class="h-badge ${cls}">${isP ? "Phishing" : "Aman"}</span>
          <span class="h-time">${timeAgo(item.timestamp)}</span>
        </div>`;
    }).join("");
  });
}

function clearHistory() {
  if (!confirm("Hapus semua riwayat scan?")) return;
  chrome.runtime.sendMessage({ type: "CLEAR_HISTORY" }, () => loadHistory());
}

// ── EXPORT & DASHBOARD ─────────────────────────────────────
function exportHistory() {
  chrome.runtime.sendMessage({ type: "GET_HISTORY" }, (response) => {
    const history = response.history || [];
    if (history.length === 0) { alert("Belum ada riwayat untuk diekspor."); return; }

    const jsonStr = JSON.stringify(history, null, 2);
    const fileName = `phishing-history-${Date.now()}.json`;

    // Gunakan chrome.downloads API — tidak butuh CDN eksternal, aman di extension
    const blob = new Blob([jsonStr], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    chrome.downloads.download({
      url: url,
      filename: fileName,
      saveAs: false
    }, () => {
      URL.revokeObjectURL(url);
    });
  });
}

function openDashboard() {
  chrome.runtime.sendMessage({ type: "GET_HISTORY" }, (response) => {
    const history = response.history || [];
    const dashboardUrl = `${WEBAPP_URL}/dashboard.html`;

    const sendData = (tabId) => {
      if (history.length === 0) return;
      // Inject postMessage ke halaman dashboard
      chrome.scripting.executeScript({
        target: { tabId },
        func: (data) => {
          window.postMessage({ type: "LOAD_HISTORY", history: data }, "*");
        },
        args: [history]
      });
    };

    // Cek apakah tab dashboard sudah terbuka
    chrome.tabs.query({}, (tabs) => {
      const existing = tabs.find(t => t.url && t.url.startsWith(dashboardUrl));
      if (existing) {
        chrome.tabs.update(existing.id, { active: true });
        chrome.windows.update(existing.windowId, { focused: true });
        setTimeout(() => sendData(existing.id), 300);
      } else {
        chrome.tabs.create({ url: dashboardUrl }, (tab) => {
          const listener = (tabId, info) => {
            if (tabId === tab.id && info.status === "complete") {
              chrome.tabs.onUpdated.removeListener(listener);
              setTimeout(() => sendData(tab.id), 500);
            }
          };
          chrome.tabs.onUpdated.addListener(listener);
        });
      }
    });
  });
}

// ── HELPERS ────────────────────────────────────────────────
function shortenUrl(url) {
  try {
    const u = new URL(url.startsWith("http") ? url : "https://" + url);
    const path = u.pathname.length > 25 ? u.pathname.substring(0, 25) + "…" : u.pathname;
    return u.hostname + path;
  } catch {
    return url.length > 45 ? url.substring(0, 45) + "…" : url;
  }
}

function escHtml(str) {
  return String(str).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}

function timeAgo(ts) {
  const m = Math.floor((Date.now() - ts) / 60000);
  if (m < 1) return "baru";
  if (m < 60) return m + "m";
  const h = Math.floor(m / 60);
  if (h < 24) return h + "j";
  return Math.floor(h / 24) + "h";
}
