// content.js — Phishing Detection Extension

(function () {
  // Kirim sinyal ke background (optional, tapi ga wajib sebenarnya)
  chrome.runtime.sendMessage({
    type: "PAGE_LOADED",
    url: window.location.href
  }).catch(err => console.log("Send PAGE_LOADED error:", err));

  // Listener untuk warning dari background
  chrome.runtime.onMessage.addListener((msg) => {
    console.log("Message received in content:", msg);

    if (msg.type === "SHOW_WARNING") {
      showPhishingBanner(msg.url);
    }
  });

  function showPhishingBanner(url) {
    // Hindari duplikat
    if (document.getElementById("pd-warning-banner")) return;

    const banner = document.createElement("div");
    banner.id = "pd-warning-banner";

    banner.style.cssText = `
      position: fixed;
      top: 0; left: 0; right: 0;
      z-index: 2147483647;
      background: #fdf5f3;
      border-bottom: 2px solid #F0997B;
      padding: 10px 20px;
      display: flex;
      align-items: center;
      gap: 12px;
      font-family: sans-serif;
      font-size: 13px;
      color: #993C1D;
      box-shadow: 0 2px 12px rgba(216,90,48,0.12);
    `;

    banner.innerHTML = `
      <span style="font-size:18px">⚠️</span>
      <span>
        <strong>Phishing Detection:</strong> 
        Halaman ini terdeteksi sebagai <strong>phishing</strong>.
        <br/>
        <small>${url}</small>
      </span>
      <button id="pd-close-btn" style="
        margin-left: auto;
        background: none;
        border: none;
        cursor: pointer;
        font-size: 18px;
        color: #993C1D;
      ">×</button>
    `;

    // Pastikan DOM siap
    if (document.body) {
      document.body.prepend(banner);
    } else {
      document.addEventListener("DOMContentLoaded", () => {
        document.body.prepend(banner);
      });
    }

    // Event close (hindari inline onclick)
    document.getElementById("pd-close-btn").addEventListener("click", () => {
      banner.remove();
    });
  }
})();